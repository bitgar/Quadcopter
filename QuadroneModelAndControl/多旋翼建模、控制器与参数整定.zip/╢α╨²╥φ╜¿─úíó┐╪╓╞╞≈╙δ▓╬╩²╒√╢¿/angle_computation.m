function [sys,x0,str,ts,simStateCompliance] = angle_computation(t,x,u,flag,mass,g)
switch flag

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2
    sys = [];

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3
    sys=mdlOutputs(t,x,u,mass,g);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9
    sys = [];

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end Quadrotor_Plant

function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

x0  = [];

str = [];

ts  = [0 0];


simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

function sys=mdlOutputs(~,~,u,mass,g)
%%
%����Բ����
pai=3.1415926535897;

%%

%%
%������ģ�Ϳ��������


%%
%С�Ƕ����Ի�ģ�Ϳ��������
R_yaw = [cos(u(4)),-sin(u(4));...
         sin(u(4)),cos(u(4))];
matrix_tmp = [0 1;...
             -1 0];
A_yaw = R_yaw * matrix_tmp;

acc_h = [u(1);u(2)];

sol = -1/g * inv(A_yaw) * acc_h;

% ��ת��
exp_roll = sol(1);
% ������
exp_pitch = sol(2);

% ����
Force = mass*g - mass*u(3);

%�޷�
angle_xian_roll = 15/180*pai;
angle_xian_pitch = 90/180*pai;

if(exp_roll >= angle_xian_roll)
    exp_roll = angle_xian_roll;
elseif(exp_roll <= -angle_xian_roll)
    exp_roll = -angle_xian_roll;
end

if(exp_pitch >= angle_xian_pitch)
    exp_pitch = angle_xian_pitch;
elseif(exp_pitch <= -angle_xian_pitch)
    exp_pitch = -angle_xian_pitch;
end

sys(1) = Force;
sys(2) = exp_roll;
sys(3) = exp_pitch;

%%

% %ת��
% pai=3.1415926535;
% 
% fai_real=fai_exp;
% theta_real=theta_exp;
% 
% fai_real_tmp=mod(fai_real,2*pai);
% theta_real_tmp=mod(theta_real,2*pai);
% 
% if (fai_real_tmp > 0) && (fai_real_tmp < pai/2.0) 
%     fai_real = fai_real_tmp;
% elseif (fai_real_tmp >= pai/2.0) && (fai_real_tmp < pai)
%     fai_real = fai_real_tmp;%pai/2.0-0.001;
% elseif (fai_real_tmp >= pai) && (fai_real_tmp < 1.5*pai)
%     fai_real = fai_real_tmp-2*pai;%1.5*pai+0.001;
% elseif (fai_real_tmp >= 1.5*pai) && (fai_real_tmp < 2.0*pai)
%     fai_real = fai_real_tmp-2*pai;    
% end
% 
% if (theta_real_tmp > 0) && (theta_real_tmp < pai/2.0) 
%     theta_real = theta_real_tmp;
% elseif (theta_real_tmp >= pai/2.0) && (theta_real_tmp < pai)
%     theta_real = theta_real_tmp-2*pai;%pai/2.0-0.001;
% elseif (theta_real_tmp >= pai) && (theta_real_tmp < 1.5*pai)
%     theta_real = theta_real_tmp-2*pai;%1.5*pai+0.001;
% elseif (theta_real_tmp >= 1.5*pai) && (theta_real_tmp < 2.0*pai)
%     theta_real = theta_real_tmp-2*pai;    
% end

% end mdlOutputs    
